package com.example.recyclerviewtest.Adapter;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recyclerviewtest.Model.CNGMonthlyReportModel;
import com.example.recyclerviewtest.Model.WEEK1;
import com.example.recyclerviewtest.R;


import java.util.ArrayList;
import java.util.List;

public class MonthlyReportVerticalData extends RecyclerView.Adapter<MonthlyReportVerticalData.MyViewHolder> {
        private ArrayList<WEEK1> dataModelArrayList;
        Context ctx;
        private LayoutInflater inflater;
        private String TAG = "MonthlyReportVerticalData";


        public MonthlyReportVerticalData(Context ctx, ArrayList<WEEK1> week1ArrayList) {
            inflater = LayoutInflater.from(ctx);
            this.dataModelArrayList = week1ArrayList;
            this.ctx = ctx;
            Log.d(TAG, "PNGRBTargetAdapter call");
        }


        @NonNull
        @Override
        public MonthlyReportVerticalData.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = inflater.inflate(R.layout.monthly_report_vertical_data_layout, parent, false);
            MonthlyReportVerticalData.MyViewHolder holder = new MonthlyReportVerticalData.MyViewHolder(view);
            return holder;
        }

        @Override
        public void onBindViewHolder(MonthlyReportVerticalData.MyViewHolder holder, int position) {
            final WEEK1 week1 = dataModelArrayList.get(position);
            Log.d(TAG,"dataModelArrayList "+position);
            holder.txtViewCngRs.setText(week1.getCNGRATE());
            holder.txtViewTotalSale.setText(week1.getTOTALSALE());
            holder.txtViewSaleValue.setText(week1.getSALEVALUE());
            holder.txtViewByCash.setText(week1.getBYCASH());
            holder.txtViewByPos.setText(week1.getBYPOS());
            holder.txtViewByPaytm.setText(week1.getBYPAYTM());


      /*  if(week1.getCashDepositAmount().equals("NA")||week1.getCashDepositAmount().equals("0")){
            holder.txtViewCashDepositAmount.setText(week1.getCashDepositAmount());
        }else {*/
            holder.txtViewCashDepositAmount.setText(week1.getCASHDEPOSITEBANK());
            // }
   /*     if(week1.getRtgsAmount().equals("NA")||week1.getRtgsAmount().equals("0")){
            holder.txtViewRtgsBankAmount.setText(week1.getRtgsAmount());
        }
        else {*/
            holder.txtViewRtgsBankAmount.setText(week1.getRTGSTOBANK());
            // }
       /* if(week1.getTotalDepositToBank().equals("NA")||week1.getTotalDepositToBank().equals("0")){
            holder.txtViewTotalDepositAmount.setText(week1.getTotalDepositToBank());
        }
        else {
            holder.txtViewTotalDepositAmount.setText(String.format("%.2f",Double.parseDouble(week1.getTotalDepositToBank())));
        }*/
            // holder.txtViewCashDepositBankName.setText(week1.getCashDepositBankName());
            // holder.txtViewRtgsBankName.setText(week1.getRtgsBankName());
            holder.txtViewTotalDepositAmount.setText(week1.getTOTALDEPOSITEBANK());
            holder.txtViewClosingCashInHandAmount.setText(week1.getCLOSINGCASH());
            holder.txtViewDate.setText(week1.getCREATEDON());
        }


        @Override
        public int getItemCount() {
            Log.d("dataModelArrayList", "dataModelArrayList size " + dataModelArrayList.size());
            return dataModelArrayList.size();
        }

        class MyViewHolder extends RecyclerView.ViewHolder {
            TextView txtViewDate, txtViewCngRs, txtViewTotalSale, txtViewByCash, txtViewByPos, txtViewByPaytm,
                    txtViewCashDepositAmount, txtViewCashDepositBankName, txtViewRtgsBankAmount, txtViewRtgsBankName,
                    txtViewTotalDepositAmount,
                    txtViewSaleValue, txtViewClosingCashInHandAmount;

            RecyclerView  recyclerView;

            public MyViewHolder(View itemView) {
                super(itemView);
                recyclerView=(RecyclerView)itemView.findViewById(R.id.recyclerView_monthly_report_vertically_adapter);
                txtViewCngRs = (TextView) itemView.findViewById(R.id.txt_view_cng_rs);
                txtViewTotalSale = (TextView) itemView.findViewById(R.id.txt_view_total_sale_amount);
                txtViewSaleValue = (TextView) itemView.findViewById(R.id.txt_view_sale_value);
                txtViewByCash = (TextView) itemView.findViewById(R.id.txt_view_by_cash);
                txtViewByPos = (TextView) itemView.findViewById(R.id.txt_view_by_pos);
                txtViewByPaytm = (TextView) itemView.findViewById(R.id.txt_view_by_paytm);
                txtViewCashDepositAmount = (TextView) itemView.findViewById(R.id.txt_view_cash_deposit_amount);
                //txtViewCashDepositBankName=(TextView)itemView.findViewById(R.id.txt_view_cash_deposit_bank_name);
                txtViewRtgsBankAmount = (TextView) itemView.findViewById(R.id.txt_view_rtgs_bank_amt);
                //txtViewRtgsBankName=(TextView)itemView.findViewById(R.id.txt_view_rtgs_bank_name);
                txtViewTotalDepositAmount = (TextView) itemView.findViewById(R.id.txt_view_total_deposit_amount);
                txtViewClosingCashInHandAmount = (TextView) itemView.findViewById(R.id.txt_view_total_closing_cash_in_hand_amount);
                txtViewDate = (TextView) itemView.findViewById(R.id.txt_view_date);
            }
        }

    }

