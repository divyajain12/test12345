package com.example.recyclerviewtest.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recyclerviewtest.Model.WEEK1;
import com.example.recyclerviewtest.Model.WEEK2;
import com.example.recyclerviewtest.R;
import com.example.samparkapp.util.RecyclerTouchListener;
import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;

public class Week1Adapter extends RecyclerView.Adapter<Week1Adapter.MyViewHolder> {
    private ArrayList<WEEK1> week1ArrayList;
    private ArrayList<WEEK2> week2s;
    Context ctx;
    private LayoutInflater inflater;
    private String TAG = "Week1Adapter";
    MonthlyReportVerticalData monthlyReportVerticalData;
    final int VIEW_TYPE_WEEK1 = 0;
    final int VIEW_TYPE_WEEK2 = 1;


    public Week1Adapter(Context ctx, ArrayList<WEEK1> week1s) {
        inflater = LayoutInflater.from(ctx);
        this.week1ArrayList = week1s;
        this.ctx = ctx;
    }


    @NonNull
    @Override
    public Week1Adapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    /*    if(viewType == VIEW_TYPE_WEEK1){
            return new MessageViewHolder(itemView);
        }

        if(viewType == VIEW_TYPE_WEEK2){
            return new ImageViewHolder(itemView);
        }*/
        Log.d(TAG, "ViewType" + viewType);
        View view = inflater.inflate(R.layout.monthly_report_adapter_layout, parent, false);
        Week1Adapter.MyViewHolder holder = new Week1Adapter.MyViewHolder(view);
        return holder;
    }


    public static class Week1ViewHolder extends RecyclerView.ViewHolder {

        public Week1ViewHolder(View itemView) {
            super(itemView);

        }
    }

    @Override
    public void onBindViewHolder(Week1Adapter.MyViewHolder holder, int position) {
        final int positionAdapter = holder.getAdapterPosition();
        final WEEK1 week1 = week1ArrayList.get(position);
        Log.d(TAG, "week1ArrayList" + positionAdapter);


    /*    holder.txtViewCngRs.setText(cngReportModel.getCngRs());
        holder.txtViewTotalSale.setText((cngReportModel.getTotalSale()));
        holder.txtViewSaleValue.setText(cngReportModel.getSaleValue());
        holder.txtViewByCash.setText(cngReportModel.getByCash());
        holder.txtViewByPos.setText(cngReportModel.getByPos());
        holder.txtViewByPaytm.setText(cngReportModel.getByPaytm());
*/
        final LinearLayoutManager layoutManager = new LinearLayoutManager(ctx, LinearLayoutManager.VERTICAL, false);
        holder.recyclerView.setLayoutManager(layoutManager);
        // holder.recyclerView.setLayoutManager(new LinearLayoutManager(ctx, LinearLayoutManager.VERTICAL, false));
        monthlyReportVerticalData = new MonthlyReportVerticalData(ctx, week1ArrayList);
        holder.recyclerView.setAdapter(monthlyReportVerticalData);
        // recyclerView.setHorizontalScrollBarEnabled(true);
        holder.recyclerView.setHasFixedSize(true);
        holder.recyclerView.addOnItemTouchListener(new RecyclerTouchListener(ctx, holder.recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(@NotNull View view, int position) {
            }

            @Override
            public void onLongClick(@NotNull View view, int position) {
            }
        }));

        holder.recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                try {
                    if (newState == RecyclerView.SCROLL_STATE_DRAGGING) {
                        //Dragging
                    } else if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                        int position = layoutManager.findFirstVisibleItemPosition();
                        Log.e("onScrollStateMonthly", String.valueOf(position));
                    }
                } catch (Exception e) {
                    Log.d(TAG, "onScrollStateError" + e);
                }
            }
        });
    }


    @Override
    public int getItemCount() {
        Log.d(TAG, "week1ArrayListSize " + week1ArrayList.size());
        return week1ArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        RecyclerView recyclerView;

        public MyViewHolder(View itemView) {
            super(itemView);
            recyclerView = (RecyclerView) itemView.findViewById(R.id.recyclerView_monthly_report_vertically_adapter);
        }
    }

}
