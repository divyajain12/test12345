package com.example.recyclerviewtest.Model;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class CNGMonthlyReportModel {

    @SerializedName("StatusCode")
    @Expose
    private Integer statusCode;
    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("WEEK1")
    @Expose
    private ArrayList<WEEK1> wEEK1 = null;

    @SerializedName("WEEK2")
    @Expose
    private List<WEEK2> wEEK2 = null;

    @SerializedName("WEEK3")
    @Expose
    private List<WEEK3> wEEK3 = null;

    @SerializedName("WEEK4")
    @Expose
    private List<WEEK4> wEEK4 = null;


    public List<WEEK3> getwEEK3() {
        return wEEK3;
    }

    public void setwEEK3(List<WEEK3> wEEK3) {
        this.wEEK3 = wEEK3;
    }

    public List<WEEK4> getwEEK4() {
        return wEEK4;
    }

    public void setwEEK4(List<WEEK4> wEEK4) {
        this.wEEK4 = wEEK4;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<WEEK1> getWEEK1() {
        return wEEK1;
    }

    public void setWEEK1(ArrayList<WEEK1> wEEK1) {
        this.wEEK1 = wEEK1;
    }

    public List<WEEK2> getWEEK2() {
        return wEEK2;
    }

    public void setWEEK2(List<WEEK2> wEEK2) {
        this.wEEK2 = wEEK2;
    }
}
