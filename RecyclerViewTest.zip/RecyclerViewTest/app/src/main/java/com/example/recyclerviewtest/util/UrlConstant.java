package com.example.recyclerviewtest.util;

/**
 * Created by prince on 4/4/2016.
 */
public class UrlConstant {
    /*  QUALITY URL*/
    private static final String BASE_URL = "https://gailebank.gail.co.in:4431/WA_SAMPARK/api/";
    /*  PRODUCTION URL*/
    // public static final String BASE_URL="https://gailebank.gail.co.in:4431/mobilewebapi_qar/api/"; https://gailebank.gail.co.in:4431/mobileWebAPI_QAR/api/PMSData/DailyPNGConnection

    /*PROJECT OPERATION MODULE*/
    public static final String LOGIN_URL = BASE_URL + "User/UserAuthentication";
    public static final String DailyPNGCONNECTION_URL = BASE_URL + "PMSData/DailyPNGConnection";
    public static final String GET_GEOGRAPHICAL_AREA_URL = BASE_URL + "PMSData/GetGeographicalArea";
    public static final String GET_FINANCIAL_YEAR = BASE_URL + "PMSData/GetFinancialYear";
    public static final String GET_PNGRB_TARGET_YEAR = BASE_URL + "PMSData/GetPNGREGTargetYear";
    public static final String GET_GROUP_AREA = BASE_URL + "PMSData/GetGroupArea";
    public static final String GET_GEOGRAPHICAL_AREA_BY_GROUP = BASE_URL + "PMSData/GetGeographicalAreaByGroup";
    public static final String GET_PNG_TARGET = BASE_URL + "PMSData/GetPNGTarget";


   /* https://gailebank.gail.co.in:4431/mobileWebAPI_QAR/api/Report/cngtotsale

    https://gailebank.gail.co.in:4431/mobileWebAPI_QAR/api/Report/CNGstation

    https://gailebank.gail.co.in:4431/mobileWebAPI_QAR/api/Report/CngReport

    https://gailebank.gail.co.in:4431/mobileWebAPI_QAR/api/Report/GAList
*/

    /* CNG SALE MODULE*/ //
    public static final String CNG_STATION_URL = BASE_URL + "Report/CNGstation";
    public static final String CNG_GA_LIST_URL = BASE_URL + "Report/GAList";
    public static final String CNG_REPORT_URL = BASE_URL + "Report/CngReport";
    public static final String CNG_TOTAL_SALE_URL = BASE_URL + "Report/cngtotsale";
    public static final String CNG_CLOSING_CASH_AMOUNT_URL = BASE_URL + "Report/cngtotsale";
    public static final String CNG_REPORT_FILTER_BY_DATE_URL=BASE_URL+"Report/Getdatabydate";
    public static final String MONTH_LIST_URL = BASE_URL+"Report/MONTH";
    public static final String CNG_GET_DATA_BY_MONTH=BASE_URL+"Report/GetdatabyMonth";
    public static final String EMPLOYEE_LOGIN_URL = "https://gailebank.gail.co.in:4431/WA_GLOBAL_GGL/API/Global/EmployeeLoginreturncpf";

   /* ATTENDANCE MODULE*/
    public static final String GET_USER_LOCATION_LIST_URL=BASE_URL+"LockAttendance/Location";
    public static final String LOCK_ATTENDANCE_URL=BASE_URL+"LockAttendance/Lockattendance";
    public static final String DEPARTMENT_URL=BASE_URL+"LockAttendance/Department";
    public static final String EMPLOYEE_LIST_URL=BASE_URL+"LockAttendance/USER_LIST";
    public static final String CITY_URL=BASE_URL+"LockAttendance/getcityname";
    public static final String AVAILABLE_REPORT_URL=BASE_URL+"LockAttendance/Reportdepartmentwise"; //"LockAttendance/AvailableReport";


}
