package com.example.recyclerviewtest.util;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;

import com.example.recyclerviewtest.R;

/**
 * Created by Ashish on 12/24/2015.
 */

public class DialogBoxHelper {

    private Context mContext;
    private ProgressDialog pDialog;

    public DialogBoxHelper(Activity activity) {


        pDialog = new ProgressDialog(activity , R.style.MyAlertDialogStyle);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
    }

    public void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    public void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.hide();
        pDialog.cancel();
    }




}
