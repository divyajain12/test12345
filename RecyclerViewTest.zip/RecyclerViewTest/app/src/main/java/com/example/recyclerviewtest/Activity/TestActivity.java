package com.example.recyclerviewtest.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Spinner;

import com.android.volley.NetworkError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.example.recyclerviewtest.Adapter.Week1Adapter;
import com.example.recyclerviewtest.Adapter.Week2Adapter;
import com.example.recyclerviewtest.Model.CNGMonthlyReportModel;
import com.example.recyclerviewtest.Model.CngReportModel;
import com.example.recyclerviewtest.Model.WEEK1;
import com.example.recyclerviewtest.Model.WEEK2;
import com.example.recyclerviewtest.Model.WEEK3;
import com.example.recyclerviewtest.Model.WEEK4;
import com.example.recyclerviewtest.Network.CustomRequestJson;
import com.example.recyclerviewtest.R;
import com.example.recyclerviewtest.util.AppController;
import com.example.recyclerviewtest.util.DialogBoxHelper;
import com.example.recyclerviewtest.util.Helper;
import com.example.recyclerviewtest.util.UrlConstant;
import com.example.samparkapp.util.RecyclerTouchListener;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class TestActivity extends AppCompatActivity {

    String monthId = "", groupAreaId = "", cngStationId = "";
    RecyclerView recyclerViewHorizontal;
    ArrayList<CngReportModel> cngReportModelArrayList;
    private CNGMonthlyReportModel cngMonthlyReportModel;
    ArrayList<CNGMonthlyReportModel> cngMonthlyReportModelArrayList;
    DialogBoxHelper dialogBoxHelper;
    String TAG = "TestActivity";
    ArrayList<WEEK1> week1s;
    ArrayList<WEEK2> week2s;
    ArrayList<WEEK3> week3s;
    ArrayList<WEEK4> week4s;
    String weekPosition="";
    private Week1Adapter week1Adapter;
    private Week2Adapter week2Adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        cngMonthlyReportModelArrayList = new ArrayList<>();
        week1s = new ArrayList<>();
        week2s = new ArrayList<>();
        widgetInitialize();

        tapToHitTheReportServiceRequest();
       // final LinearLayoutManager linearLayoutManager = null;
        final LinearLayoutManager layoutManager = new LinearLayoutManager(TestActivity.this,LinearLayoutManager.HORIZONTAL,false);
        recyclerViewHorizontal.setLayoutManager(layoutManager);

       // recyclerView.setLayoutManager(new LinearLayoutManager(TestActivity.this, LinearLayoutManager.HORIZONTAL, false));


        // recyclerView.setHorizontalScrollBarEnabled(true);
        //recyclerView.setHasFixedSize(true);
        recyclerViewHorizontal.addOnItemTouchListener(new RecyclerTouchListener(TestActivity.this, recyclerViewHorizontal, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(@NotNull View view, int position) {
                Log.d(TAG, "position" + position);
                recyclerViewHorizontal.scrollToPosition(position);
                recyclerViewHorizontal.smoothScrollToPosition(position);
            }

            @Override
            public void onLongClick(@NotNull View view, int position) {
            }
        }));

        // CHECK INDEX FOR RECYCLER VIEW
        recyclerViewHorizontal.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                try {
                    if (newState == RecyclerView.SCROLL_STATE_DRAGGING) {
                        //Dragging
                    } else if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                      int position = layoutManager.findFirstVisibleItemPosition();
                        weekPosition=String.valueOf(position);
                        Log.e("onScrollStatePosition", String.valueOf(position));


                    }
                }catch (Exception e){
                    Log.d(TAG,"onScrollStateChangedError"+e);
                }


            }
        });

   /*     if(weekPosition.equals("0")){
            week1Adapter = new Week1Adapter(TestActivity.this, week1s);
            recyclerViewHorizontal.setAdapter(week1Adapter);
        }if (weekPosition.equals("1")){
            week1Adapter = new Week1Adapter(TestActivity.this, week1s);
            recyclerViewHorizontal.setAdapter(week1Adapter);
        }else {
            Log.d(TAG,"onScrollStateChangedError");
        }*/

        week1Adapter = new Week1Adapter(TestActivity.this, week1s);
        recyclerViewHorizontal.setAdapter(week1Adapter);
    }

    private void widgetInitialize() {
        recyclerViewHorizontal = (RecyclerView) findViewById(R.id.horizontal_recyclerView_monthly_report);
    }

    /*  WEEKLY REPORT CALL FUNCTION*/
    private void tapToHitTheReportServiceRequest() {
        dialogBoxHelper = new DialogBoxHelper(TestActivity.this);
        dialogBoxHelper.showProgressDialog();
        Map<String, String> params = new LinkedHashMap<>();
        params.put("GA_ID", "3"); //GA_ID
        params.put("STATION_ID", "6"); //STATION_ID
        params.put("MONTH_ID", "04"); // MONTH_ID

        AppController.getInstance().addToRequestQueue(new CustomRequestJson(TestActivity.this, Request.Method.POST,
                UrlConstant.CNG_GET_DATA_BY_MONTH, params, cngReportServiceRequest,
                errorListener), "tag_save_address_req");
    }

    private Response.Listener<JSONObject> cngReportServiceRequest = new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject response) {
            dialogBoxHelper.hideProgressDialog();
            try {
                Gson gson = new Gson();
                cngMonthlyReportModel = gson.fromJson(response.toString(), CNGMonthlyReportModel.class);

                Log.d("groupAreaServiceRequest", "groupAreaServiceRequest response" + response.toString());
                JSONObject j = null;
                if ((response.getInt("StatusCode") == 200)) {
                    JSONArray jsonArrayWeek1 = new JSONArray();
                    JSONArray jsonArrayWeek2 = new JSONArray();


                    jsonArrayWeek1 = response.getJSONArray("WEEK1");
                    Log.d(TAG, "jsonArray length" + jsonArrayWeek1.length());


                    if(jsonArrayWeek1.length()>0) {
                        for (int i = 0; i < jsonArrayWeek1.length(); i++) {
                            JSONObject jsonObject = jsonArrayWeek1.getJSONObject(i);
                            WEEK1 week1 = new WEEK1();
                            week1.setCNGRATE(jsonObject.getString("CNG_RATE"));
                            week1.setTOTALSALE(jsonObject.getString("TOTAL_SALE"));
                            week1.setSALEVALUE(jsonObject.getString("SALE_VALUE"));
                            week1.setBYCASH(jsonObject.getString("BY_CASH"));
                            week1.setBYPOS(jsonObject.getString("BY_POS"));
                            week1.setBYPAYTM(jsonObject.getString("BY_PAYTM"));
                            week1.setCASHDEPOSITEBANK(jsonObject.getString("CASH_DEPOSITE_BANK"));
                            week1.setRTGSTOBANK(jsonObject.getString("RTGS_TO_BANK"));
                            week1.setTOTALDEPOSITEBANK(jsonObject.getString("TOTAL_DEPOSITE_BANK"));
                            week1.setCLOSINGCASH(jsonObject.getString("CLOSING_CASH"));
                            week1.setCREATEDON(jsonObject.getString("CREATED_ON"));
                            week1s.add(week1);
                        }
                        week1Adapter.notifyDataSetChanged();
                    }
                    if(jsonArrayWeek2.length()>0) {
                        for (int i = 0; i < jsonArrayWeek2.length(); i++) {
                            JSONObject jsonObject = jsonArrayWeek2.getJSONObject(i);
                            WEEK2 week2 = new WEEK2();
                            week2.setCNGRATE(jsonObject.getString("CNG_RATE"));
                            week2.setTOTALSALE(jsonObject.getString("TOTAL_SALE"));
                            week2.setSALEVALUE(jsonObject.getString("SALE_VALUE"));
                            week2.setBYCASH(jsonObject.getString("BY_CASH"));
                            week2.setBYPOS(jsonObject.getString("BY_POS"));
                            week2.setBYPAYTM(jsonObject.getString("BY_PAYTM"));
                            week2.setCASHDEPOSITEBANK(jsonObject.getString("CASH_DEPOSITE_BANK"));
                            week2.setRTGSTOBANK(jsonObject.getString("RTGS_TO_BANK"));
                            week2.setTOTALDEPOSITEBANK(jsonObject.getString("TOTAL_DEPOSITE_BANK"));
                            week2.setCLOSINGCASH(jsonObject.getString("CLOSING_CASH"));
                            week2.setCREATEDON(jsonObject.getString("CREATED_ON"));
                            week2s.add(week2);
                        }
                        week2Adapter.notifyDataSetChanged();
                    }



                } else {
                    Helper.showLongToast(getApplicationContext(), "No Data Found");
                }

               // monthlyReportAdapter.notifyDataSetChanged();
            } catch (Exception e) {
                Log.d(TAG, "tapToHitTheReportServiceRequestException " + e);
                dialogBoxHelper.hideProgressDialog();
                Helper.showLongToast(getApplicationContext(), "Server Error");
                e.printStackTrace();
            }
        }
    };


    Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError volleyError) {
            dialogBoxHelper.hideProgressDialog();
            Log.d("response", volleyError.toString());
            try {
                if (volleyError instanceof ServerError) {
                    Helper.showShortToast(TestActivity.this, "Server Error try again...");
                } else if (volleyError instanceof TimeoutError) {
                    Helper.showShortToast(TestActivity.this, "Timeout please try again...");
                } else if (volleyError instanceof NetworkError) { ///No internet Please check internet connection...
                    Helper.showShortToast(TestActivity.this, " connection...");
                } else {
                    Helper.showShortToast(TestActivity.this, "Oop's something went wrong please try again...");
                }

            } catch (Exception e) {
                //Handle a malformed json response
            }
        }
    };

}
